# Control Dribble Flutter

This is a Flutter project converted from the HTML+JS version.

## Setup

### Android
- Ensure you have `android.permission.CAMERA` and `android.permission.RECORD_AUDIO` in `AndroidManifest.xml` (already included).
- Uses ML Kit for pose detection.

### iOS
- Add camera and microphone usage descriptions in `Info.plist` (already included).

### Run
```bash
flutter pub get
flutter run
```
